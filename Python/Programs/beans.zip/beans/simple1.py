# A very stupid simple player that always removes 1 bean

def player(beans):
    return 1
    
