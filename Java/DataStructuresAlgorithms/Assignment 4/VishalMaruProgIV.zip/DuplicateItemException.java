public class DuplicateItemException extends Exception
{
	
	public DuplicateItemException()
	{
		super();
	}
	
	public DuplicateItemException(String msg)
	{
		super(msg);
	}
}