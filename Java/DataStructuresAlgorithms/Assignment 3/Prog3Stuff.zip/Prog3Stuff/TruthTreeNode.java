//a truth tree node class
public class TruthTreeNode {
	
	private String pcSentence;
	private TruthTreeNode leftChild;
	private TruthTreeNode rightChild;
	private TruthTreeNode parent;
	private boolean checked;
	private boolean closed;

//a constructor
	public TruthTreeNode(String pcSentence) {
		this.pcSentence = pcSentence;
		this.leftChild = null;
		this.rightChild = null;
		this.parent = null;
		this.checked = false;
		this.closed = false;
	}
//another constructor - not needed for this program
	public TruthTreeNode(String pcSentence,TruthTreeNode leftChild, TruthTreeNode rightChild, TruthTreeNode parent, boolean checked, boolean closed) {
		this.pcSentence = pcSentence;
		this.leftChild = leftChild;
		this.rightChild = rightChild;
		this.parent = parent;
		this.checked = false;
		this.closed = false;
	}
//get the left component of a conjunction, disjunction, conditional or biconditional
	public static String getLeftComponent(String expression) {
	
		int index = 1;
		int counter = 1;
		do {
			switch(expression.charAt(index)) {
				case 'p':
				case 'q':
				case 'r':
				case 's':
				case 't':
					counter--;
					index++;
					break;
				case '-':
					index++;
					break;
				case 'v':
				case '&':
				case '>':
				case '=':
					counter++;
					index++;
					break;
			}
		} while (counter != 0 && index < expression.length());
			return expression.substring(1,index);
	}
//get the right component of a conjunction, disjunction, conditional or biconditional
	public static String getRightComponent(String expression) {
	
		int index = 1;
		int counter = 1;
		do {
			
			switch(expression.charAt(index)) {
				case 'p':
				case 'q':
				case 'r':
				case 's':
				case 't':
					counter--;
					index++;
					break;
				case '-':
					index++;
					break;
				case 'v':
				case '&':
				case '>':
				case '=':
					counter++;
					index++;
					break;
			}
		} while (counter > 0 && index < expression.length());
			return expression.substring(index);
	}
//a setter method for the "cargo"
	public void setPcSentence(String pcSentence) {
		this.pcSentence = pcSentence;
	}
//a getter method
	public String getPcSentence() {
		return pcSentence;
	}
//You need to supply the rest of the setters and getters
	
//A method to determine whether the sentence is a disjunction
//You need to supply similar methods for the other 8 kinds of sentences
	public boolean isDisjunction(String pcSentence) {
		if (pcSentence.charAt(0) == 'v')
			return true;
		return false;
	}
	
//A method for attaching new leaves
	public void attach(String pcSentence) {
		//if the sentence is a disjunction, attach like this
		if (this.isDisjunction(pcSentence) ) {
			TruthTreeNode left = new TruthTreeNode(this.getLeftComponent(pcSentence));
			this.setLeftChild(left);
			left.setParent(this);
			//if it's atomic or the negation of an atomic sentence, check it
			if (left.getPcSentence().length() <= 2)
				left.setChecked(true);
			TruthTreeNode right = new TruthTreeNode(this.getRightComponent(pcSentence));
			this.setRightChild(right);
			right.setParent(this);
			//if it's atomic or the negation of an atomic sentence, check it
			if (right.getPcSentence().length() <= 2)
				right.setChecked(true);
		}
		//if the sentence is a conjunction attach like this
		if (this.isConjunction(pcSentence)) {
			TruthTreeNode left = new TruthTreeNode(this.getLeftComponent(pcSentence));
			this.setLeftChild(left);
			left.setParent(this);
			//if it's atomic or the negation of an atomic sentence, check it
			if (left.getPcSentence().length() <= 2)
				left.setChecked(true);
			//have to check for closure here
			boolean isClosed = false;
			TruthTreeNode temp = left;
			while (temp.getParent() != null) {
				temp = temp.getParent();
				if (isContradiction(left.getPcSentence(), temp.getPcSentence()))
					isClosed = true;
			}
			
			TruthTreeNode leftleft = new TruthTreeNode(this.getRightComponent(pcSentence));
			left.setLeftChild(leftleft);
			leftleft.setParent(left);
			//if it's atomic or the negation of an atomic sentence, check it
			if (leftleft.getPcSentence().length() <= 2)
				leftleft.setChecked(true);
			//if the branch was closed because of the left conjunct, close the branch here
			if (isClosed)
				leftleft.setClosed(true);
		}
//You have seven other cases to do!!		
	}
	
//A method that returns true if sentence1 and sentence2 constitute a contradiction
//Implement it!!
	public boolean isContradiction(String sentence1, String sentence2) {
		
	}
//A method to determine if a branch is closed.  Implement it!!
	public boolean findIfClosed(TruthTreeNode leaf) {
		
	}
}